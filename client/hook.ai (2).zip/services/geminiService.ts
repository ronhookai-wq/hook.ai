import { GoogleGenAI, Modality, GenerateContentResponse } from '@google/genai';
import { ImageStyle, AspectRatio } from '../types';

// This service makes actual calls to the Gemini API.

// Ensure the environment variable is read.
const apiKey = process.env.API_KEY;
if (!apiKey) {
    // This is a client-side app, process.env.API_KEY is handled by the platform.
    console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}
const ai = new GoogleGenAI({ apiKey: apiKey || 'mock_api_key' });

export const generateImage = async (
  prompt: string,
  style: ImageStyle,
  aspectRatio: AspectRatio,
): Promise<string> => {
  console.log(`Generating image with prompt: "${prompt}", style: ${style}, aspect ratio: ${aspectRatio}`);
  
  try {
    const fullPrompt = `${prompt}, in the style of ${style}.`;
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: fullPrompt }] },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        const base64ImageBytes: string = part.inlineData.data;
        return `data:image/png;base64,${base64ImageBytes}`;
      }
    }
    throw new Error("No image data in response");

  } catch (error) {
    console.error("Error generating image with Gemini:", error);
    throw error;
  }
};

export const magicEdit = async (
  base64ImageData: string,
  prompt: string
): Promise<string> => {
    console.log(`Applying magic edit with prompt: "${prompt}"`);
  
  try {
      const imagePart = {
          inlineData: {
              data: base64ImageData.split(',')[1],
              mimeType: 'image/png',
          },
      };
      const textPart = { text: prompt };

      const response: GenerateContentResponse = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [imagePart, textPart] },
          config: {
              responseModalities: [Modality.IMAGE],
          },
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          return `data:image/png;base64,${base64ImageBytes}`;
        }
      }
      throw new Error("No image data in response");

  } catch (error) {
      console.error("Error with magic edit:", error);
      throw error;
  }
};

export const upscaleImage = async (base64ImageData: string): Promise<string> => {
    console.log("Upscaling image");
    
    try {
        const imagePart = {
            inlineData: {
                data: base64ImageData.split(',')[1],
                mimeType: 'image/png',
            },
        };
        const textPart = { text: "Upscale this image, enhance details, increase resolution, make it high quality." };
  
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
  
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            return `data:image/png;base64,${base64ImageBytes}`;
          }
        }
        throw new Error("No image data in response");
  
    } catch (error) {
        console.error("Error upscaling image:", error);
        throw error;
    }
};

export const removeBackground = async (base64ImageData: string): Promise<string> => {
    console.log("Removing background");
    try {
        const imagePart = {
            inlineData: {
                data: base64ImageData.split(',')[1],
                mimeType: 'image/png',
            },
        };
        const textPart = { text: "Remove the background of this image. The subject should remain, and the background should be transparent." };
  
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [imagePart, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
  
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            return `data:image/png;base64,${base64ImageBytes}`;
          }
        }
        throw new Error("No image data in response");
  
    } catch (error) {
        console.error("Error removing background:", error);
        throw error;
    }
};
