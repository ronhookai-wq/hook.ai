import React, { useState } from 'react';
import Header from './components/Header';
import GeneratePage from './components/GeneratePage';
import UploadPage from './components/UploadPage';
import PricingPage from './components/PricingPage';
import AuthModal from './components/AuthModal';
import { User } from './types';

type Page = 'generate' | 'upload' | 'pricing';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<Page>('generate');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [imageForEditing, setImageForEditing] = useState<string | null>(null);

  // Mock user state. In a real app, this would come from a context or state management library.
  const [user, setUser] = useState<User>({
    isLoggedIn: true,
    isSubscribed: false,
    subscriptionTier: 'Free Trial',
  });

  const handleSendToEditor = (imageSrc: string) => {
    setImageForEditing(imageSrc);
    setActivePage('upload');
  };

  const handleClearInitialImage = () => {
    setImageForEditing(null);
  };

  const renderPage = () => {
    switch (activePage) {
      case 'generate':
        return <GeneratePage user={user} onUpgrade={() => setActivePage('pricing')} onSendToEditor={handleSendToEditor} />;
      case 'upload':
        return <UploadPage user={user} onUpgrade={() => setActivePage('pricing')} initialImage={imageForEditing} onClearInitialImage={handleClearInitialImage} />;
      case 'pricing':
        return <PricingPage />;
      default:
        return <GeneratePage user={user} onUpgrade={() => setActivePage('pricing')} onSendToEditor={handleSendToEditor} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Header 
        activePage={activePage} 
        setActivePage={(page) => {
          if (page !== 'upload') {
            handleClearInitialImage();
          }
          setActivePage(page);
        }}
        onSignInClick={() => setIsAuthModalOpen(true)}
      />
      <main className="flex-grow flex flex-col">
        {renderPage()}
      </main>
      {isAuthModalOpen && <AuthModal onClose={() => setIsAuthModalOpen(false)} />}
    </div>
  );
};

export default App;