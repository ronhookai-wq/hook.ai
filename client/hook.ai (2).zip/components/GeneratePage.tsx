import React, { useState } from 'react';
import ControlPanel from './ControlPanel';
import ImagePreview from './ImagePreview';
import ImageActions from './ImageActions';
import MagicEditModal from './MagicEditModal';
import { AspectRatio, ImageStyle, User, TextOverlay } from '../types';
import { generateImage, magicEdit, upscaleImage, removeBackground } from '../services/geminiService';

interface ImageState {
  src: string | null;
  textOverlays: TextOverlay[];
  selectedTextId: number | null;
}

const initialImageState: ImageState = {
  src: null,
  textOverlays: [],
  selectedTextId: null,
};

interface GeneratePageProps {
  user: User;
  onUpgrade: () => void;
  onSendToEditor: (imageSrc: string) => void;
}

const GeneratePage: React.FC<GeneratePageProps> = ({ user, onUpgrade, onSendToEditor }) => {
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState<ImageStyle>(ImageStyle.Cinematic);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>(AspectRatio.SixteenNine);
  const [imageStates, setImageStates] = useState<[ImageState, ImageState]>([initialImageState, initialImageState]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [isMagicEditModalOpen, setIsMagicEditModalOpen] = useState(false);
  const [editingImageIndex, setEditingImageIndex] = useState<number | null>(null);

  const handleGenerate = async () => {
    setIsProcessing(true);
    setError(null);
    setImageStates([initialImageState, initialImageState]);
    try {
      const results = await Promise.all([
        generateImage(prompt, style, aspectRatio),
        generateImage(prompt, style, aspectRatio)
      ]);
      setImageStates([
        { ...initialImageState, src: results[0] },
        { ...initialImageState, src: results[1] }
      ]);
    } catch (err) {
      setError('Failed to generate images. Please try again.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const updateImageState = (index: number, newSrc: string) => {
    setImageStates(prev => {
      const newStates = [...prev] as [ImageState, ImageState];
      newStates[index] = { ...newStates[index], src: newSrc };
      return newStates;
    });
  };

  const openMagicEditModal = (index: number) => {
    const { src } = imageStates[index];
    if (!src) return;
    setEditingImageIndex(index);
    setIsMagicEditModalOpen(true);
  };

  const handleMagicEditSubmit = async (editPrompt: string) => {
    if (editingImageIndex === null) return;
    const { src } = imageStates[editingImageIndex];
    if (!src) return;
    
    setIsProcessing(true);
    setIsMagicEditModalOpen(false);
    try {
      const result = await magicEdit(src, editPrompt);
      updateImageState(editingImageIndex, result);
      if (!user.isSubscribed) {
        alert("Magic Edit applied! Upgrade to a Pro plan to download your creation without a watermark.");
      }
    } catch (err) {
      setError('Magic Edit failed.');
    } finally {
      setIsProcessing(false);
      setEditingImageIndex(null);
    }
  };

  const handleUpscale = async (index: number) => {
    const { src } = imageStates[index];
    if (!src) return;
    setIsProcessing(true);
    try {
      const result = await upscaleImage(src);
      updateImageState(index, result);
    } catch (err) {
      setError('Upscale failed.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleRemoveBackground = async (index: number) => {
    const { src } = imageStates[index];
    if (!src) return;
    setIsProcessing(true);
    try {
      const result = await removeBackground(src);
      updateImageState(index, result);
    } catch (err) {
      setError('Background removal failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAddText = (index: number) => {
    const newText: TextOverlay = {
      id: Date.now(),
      text: 'Editable Text',
      x: 50,
      y: 50,
      scale: 1,
      rotation: 0,
      color: '#FFFFFF',
      fontFamily: 'Inter',
    };
    setImageStates(prev => {
      const newStates = [...prev] as [ImageState, ImageState];
      const updatedOverlays = [...newStates[index].textOverlays, newText];
      newStates[index] = { ...newStates[index], textOverlays: updatedOverlays, selectedTextId: newText.id };
      return newStates;
    });
  };

  const handleTextChange = (index: number, overlays: TextOverlay[]) => {
    setImageStates(prev => {
      const newStates = [...prev] as [ImageState, ImageState];
      newStates[index] = { ...newStates[index], textOverlays: overlays };
      return newStates;
    });
  };

  const handleSelectText = (index: number, id: number | null) => {
    setImageStates(prev => {
      const newStates = [...prev] as [ImageState, ImageState];
      newStates[index] = { ...newStates[index], selectedTextId: id };
      return newStates;
    });
  };

  return (
    <div className="flex-grow flex flex-col lg:flex-row gap-6 p-6 bg-gray-900" style={{ backgroundImage: 'radial-gradient(circle at top right, rgba(4,120,87,0.1), transparent 40%)' }}>
      <div className="w-full lg:w-96 flex-shrink-0">
        <ControlPanel
          isGeneratePage={true}
          prompt={prompt}
          setPrompt={setPrompt}
          style={style}
          setStyle={setStyle}
          aspectRatio={aspectRatio}
          setAspectRatio={setAspectRatio}
          onGenerate={handleGenerate}
          isProcessing={isProcessing}
          user={user}
          onUpgrade={onUpgrade}
        />
      </div>
      <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {error && <p className="text-red-500 col-span-full text-center">{error}</p>}
        {imageStates.map((state, index) => (
            <div key={index} className="flex flex-col">
              <ImagePreview
                src={state.src}
                isLoading={isProcessing && !state.src}
                aspectRatio={aspectRatio}
                textOverlays={state.textOverlays}
                onTextOverlaysChange={(overlays) => handleTextChange(index, overlays)}
                selectedTextId={state.selectedTextId}
                onSelectedTextIdChange={(id) => handleSelectText(index, id)}
              />
              <ImageActions 
                src={state.src}
                isProcessing={isProcessing}
                user={user}
                onAddText={() => handleAddText(index)}
                onMagicEdit={() => openMagicEditModal(index)}
                onUpscale={() => handleUpscale(index)}
                onRemoveBackground={() => handleRemoveBackground(index)}
                onSendToEditor={() => state.src && onSendToEditor(state.src)}
              />
            </div>
          ))}
      </div>
      <MagicEditModal 
        isOpen={isMagicEditModalOpen}
        onClose={() => setIsMagicEditModalOpen(false)}
        onSubmit={handleMagicEditSubmit}
        isProcessing={isProcessing}
      />
    </div>
  );
};

export default GeneratePage;